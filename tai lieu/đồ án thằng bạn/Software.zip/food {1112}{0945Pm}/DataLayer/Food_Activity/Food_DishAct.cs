﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace DataLayer.Food_Activity
{
    public class Food_DishAct : IDish
    {
        public bool checkName(string dishName)
        {
            using (ModelContext db = new ModelContext())
            {
                bool isExist = db.dish_list.Any(dis => dis.name == dishName);
                if (isExist)
                {
                    return true;
                }
                else
                    return false;
            }
        }

        public void delete(Food_Dish obj)
        {
            using (ModelContext db = new ModelContext())
            {
                db.Entry<Food_Dish>(obj).State = EntityState.Deleted;
                db.SaveChanges();
            }
        }

        public void edit(Food_Dish dishEdit, string E_Dname, int E_DPrice, string E_DDescription,string E_DImage, string E_DType, string E_DSize,int E_DId)
        {
            using (ModelContext db = new ModelContext())
            {
                Food_Size fsi = db.size_list.FirstOrDefault(fsize => fsize.name == E_DSize);
                Food_Type ftyp = db.type_list.FirstOrDefault(typ => typ.nameType == E_DType);
                dishEdit = (from dish in db.dish_list
                            where dish.Id == E_DId
                            select dish).First();

                dishEdit.name = E_Dname;
                dishEdit.price = E_DPrice;
                dishEdit.description = E_DDescription;
                dishEdit.imaGeURL = E_DImage;
                dishEdit.TypeId = ftyp.Id;
                dishEdit.SizeId = fsi.Id;
                db.SaveChanges();
            }
        }

        public List<Food_Dish> GetAll()
        {
            using (ModelContext db = new ModelContext())
            {
                return db.dish_list.ToList();
            }
        }
        public void insert(string DishName,int DishPrice,string DishDescription,string DishImage, string TypeName, string SizeName)
        {
            using (ModelContext db = new ModelContext())
            {
                Food_Size fsi = db.size_list.FirstOrDefault(fsize => fsize.name == SizeName);
                Food_Type ftyp = db.type_list.FirstOrDefault(ftype => ftype.nameType == TypeName);
                db.dish_list.Add(new Food_Dish {name=DishName,price=DishPrice,description=DishDescription,imaGeURL=DishImage, TypeId=ftyp.Id, SizeId=fsi.Id});
                db.SaveChanges();
            }
                
        }

        public List<Food_Dish> search(string name)
        {
            using (ModelContext db = new ModelContext())
            {
                var searchResult = from dis in db.dish_list
                                   where dis.name.Contains(name)
                                   select dis;
                return searchResult.ToList();
            }
        }

        public List<Food_Dish> sizeFilter(int D_SizeId)
        {
            using (ModelContext db = new ModelContext())
            {
                var filterResult = from dish in db.dish_list
                                   where dish.SizeId == D_SizeId
                                   select dish;
                return filterResult.ToList();
            }
        }

        public List<Food_Dish> typeFilter(int D_TypeId)
        {
            using (ModelContext db = new ModelContext())
            {
                var filterResult = from dish in db.dish_list
                                   where dish.TypeId == D_TypeId
                                   select dish;
                return filterResult.ToList();
            }
        }

        public void uploadImage(Food_Dish obj)
        {
            using (ModelContext db = new ModelContext())
            {
                
            }
        }
    }
}
