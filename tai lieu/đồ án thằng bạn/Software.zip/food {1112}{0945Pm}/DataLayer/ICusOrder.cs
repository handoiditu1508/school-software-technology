﻿using System;
using System.Collections.Generic;
using System.Linq;
using Model;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public interface ICusOrder
    {
        void insert(string name, int price, int numberDish, DateTime orderdate);
        void clearAll();
        List<CusOrders> GetAll();
        int TotalCost();
        void delete(CusOrders obj);
        void changeQuantity(CusOrders obj);
        bool checkFDup(string name);
    }
}
