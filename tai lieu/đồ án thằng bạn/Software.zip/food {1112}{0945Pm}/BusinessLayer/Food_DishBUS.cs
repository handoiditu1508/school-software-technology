﻿using System;
using System.Collections.Generic;
using System.Linq;
using DataLayer.Food_Activity;
using Model;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class Food_DishBUS
    {
        static IDish dish_act;        
        static Food_DishBUS()
        {
            dish_act = new Food_DishAct();            
        }
        public static List<Food_Dish> GetAll()
        {
            return dish_act.GetAll();
        }
        public static void insert (string DishN,int DishP,string DishD,string DishI, string typeName,string sizeName)
        {
            dish_act.insert(DishN,DishP,DishD,DishI,typeName,sizeName);
        }
        public static void delete (Food_Dish Fdish)
        {
            dish_act.delete(Fdish);
        }
        public static List<Food_Dish> search(string F_DName)
        {
            return dish_act.search(F_DName);
        }
        public static bool chekName( string F_D_name)
        {
            return dish_act.checkName(F_D_name);
        }
        public static void edit(Food_Dish E_Dish, string E_DishN,int E_DishP,string E_DishD,string E_DishI,string E_Type,string E_Size,int E_DishID)
        {
            dish_act.edit(E_Dish,E_DishN, E_DishP, E_DishD, E_DishI,E_Type, E_Size,E_DishID);
        }
        public static List<Food_Dish> D_TypeFilter(int typeId)
        {
            
            return dish_act.typeFilter(typeId);
        }
        public static List<Food_Dish> D_SizeFilter(int sizeId)
        {
            
            return dish_act.sizeFilter(sizeId);
        }
    }
}
