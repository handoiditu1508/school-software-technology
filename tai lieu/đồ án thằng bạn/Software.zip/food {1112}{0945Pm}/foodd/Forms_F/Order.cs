﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using Model;
using BusinessLayer;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace foodd.Forms_F
{
    
    public partial class Order : Form
    {
        static bool isDone;
        public Order()
        {
            InitializeComponent();
            this.MaximumSize = this.Size;
            this.MinimumSize = this.Size;


            txtChangeQuan.Enabled = false;
            btnChangeQuan.Enabled = false;
            dataDishView.Focus();
        }

        private void btnDataGridRef_Click(object sender, EventArgs e)
        {
            foodSizeBindingSource.DataSource = Food_SizeBUS.GetAll();
            foodTypeBindingSource.DataSource = Food_TypeBUS.GetAll();
            combSizeFilter.DataSource = Food_SizeBUS.GetAll();
            combTypeFilter.DataSource = Food_TypeBUS.GetAll();
            foodDishBindingSource.DataSource = Food_DishBUS.GetAll();
            txtSearchName.Clear();

        }

        private void combTypeFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            int typId = int.Parse(combTypeFilter.SelectedValue.ToString());
            foodDishBindingSource.DataSource = Food_DishBUS.D_TypeFilter(typId);
        }

        private void combSizeFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            int sizId = int.Parse(combSizeFilter.SelectedValue.ToString());
            foodDishBindingSource.DataSource = Food_DishBUS.D_SizeFilter(sizId);            
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            cusOrdersBindingSource.Add(new CusOrders());
            cusOrdersBindingSource.MoveLast();
            Food_Dish fd = foodDishBindingSource.Current as Food_Dish;
            if (fd != null)
            {
                if(txtNumberD!=null&&txtNumberD.Text!=""&&int.Parse(txtNumberD.Text)!=0)
                {
                    string dName = fd.name;
                    int dPrice = fd.price;
                    int quantity = int.Parse(txtNumberD.Text);
                    DateTime orderdate = DateTime.Now;
                    if(CusOrderBUS.checkFDup(dName)==false)
                    {
                        CusOrderBUS.insert(dName, dPrice, quantity, orderdate);

                        cusOrdersBindingSource.MoveLast();
                        cusOrdersBindingSource.DataSource = CusOrderBUS.GetAll();
                        labelCost.Text = CusOrderBUS.TotalCost().ToString() + "$";
                        txtNumberD.Clear();
                    }
                    else
                    {
                        MessageBox.Show("This food is already in your list! Please chood another food.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        dataDishView.Focus();
                        cusOrdersBindingSource.RemoveCurrent();
                    }
                }
                else
                {
                    if(MessageBox.Show("Please type the quantity of your dish!","Missing your dish quantity!",MessageBoxButtons.RetryCancel,MessageBoxIcon.Information)==DialogResult.Retry)
                    {
                        cusOrdersBindingSource.MoveLast();
                        txtNumberD.Focus();
                        cusOrdersBindingSource.RemoveCurrent();
                    }
                }                
            }
            else
            {
                if(MessageBox.Show("Pleas choose your dish!", "Your order is empty!", MessageBoxButtons.RetryCancel, MessageBoxIcon.Information)==DialogResult.Retry)
                {
                    txtNumberD.Clear();
                    dataDishView.Focus();
                    cusOrdersBindingSource.RemoveCurrent();
                }
            }
            
        }

        private void dataDishView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtChangeQuan.Enabled = false;
            btnChangeQuan.Enabled = false;
            txtNumberD.Enabled = true;
            btnOrder.Enabled = true;
            Food_Dish fdish = foodDishBindingSource.Current as Food_Dish;
            if (fdish.Id != 0)
            {
                int typeID = fdish.TypeId;
                int sizeID = fdish.SizeId;
                foodTypeBindingSource.DataSource = Food_TypeBUS.showType(typeID);
                foodSizeBindingSource.DataSource = Food_SizeBUS.showSize(sizeID);
                picBox.ImageLocation = fdish.imaGeURL;
                txtNumberD.Clear();
            }
            else
            {
                return;
            }
        }

        private void txtNumberD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            CusOrders cusOrder = cusOrdersBindingSource.Current as CusOrders;
            if(cusOrder!=null)
            {
                CusOrderBUS.delete(cusOrder);
                cusOrdersBindingSource.RemoveCurrent();
                labelCost.Text = CusOrderBUS.TotalCost().ToString()+"$";
            }
            else
            {
                if(MessageBox.Show("List is empty! Please choose your food.","Error",MessageBoxButtons.OKCancel,MessageBoxIcon.Error)==DialogResult.OK)
                {
                    dataDishView.Focus();
                }
                return;
            }
        }       

        private void txtChangeQuan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void dataCusOrder_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtNumberD.Enabled = false;
            btnOrder.Enabled = false;
            txtChangeQuan.Enabled = true;
            btnChangeQuan.Enabled = true;
        }
        private void btnChangeQuan_Click(object sender, EventArgs e)
        {
            CusOrders cusO = cusOrdersBindingSource.Current as CusOrders;
            if (cusO != null)
            {
                CusOrderBUS.changeQuantity(cusO);
                dataCusOrder.Refresh();
                labelCost.Text = CusOrderBUS.TotalCost().ToString() + "$";
            }
            else
            {
                return;
            }
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            isDone = true;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(txtSearchName.Text))
            {
                return;
            }
            else
            {
                string fName = txtSearchName.Text;
                foodDishBindingSource.DataSource = Food_DishBUS.search(fName);
                txtSearchName.Clear();
                txtSearchName.Focus();
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cusOrdersBindingSource.DataSource = CusOrderBUS.GetAll();
        }
    }
}
