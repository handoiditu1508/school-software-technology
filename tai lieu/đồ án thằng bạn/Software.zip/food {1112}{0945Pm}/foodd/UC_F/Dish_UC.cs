﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Security.Permissions;
using System.Linq;
using System.Text;
using Model;
using BusinessLayer;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace foodd.UC_F
{
    public partial class Dish_UC : UserControl
    {
        public Dish_UC()
        {
            InitializeComponent();            
        }
        private void btnTypeRef_Click(object sender, EventArgs e)
        {
            foodTypeBindingSource.DataSource = Food_TypeBUS.GetAll();            
        }

        private void btnSizeRef_Click(object sender, EventArgs e)
        {
            foodSizeBindingSource.DataSource = Food_SizeBUS.GetAll();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            foodSizeBindingSource.DataSource = Food_SizeBUS.GetAll();
            foodTypeBindingSource.DataSource = Food_TypeBUS.GetAll();
            foodDishBindingSource.Add(new Food_Dish());
            foodDishBindingSource.MoveLast();
            dataGridDish.Enabled = false;
            panCRUD.Enabled = false;
            panFilter.Enabled = false;
            panSave.Enabled = true;
        }

        private void Dish_UC_Load(object sender, EventArgs e)
        {
            panSave.Enabled = false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Food_Dish fdish1 = foodDishBindingSource.Current as Food_Dish;
            if(fdish1==null)
            {
                MessageBox.Show("Nothing to edit!", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                foodDishBindingSource.DataSource = Food_DishBUS.GetAll();
                return;
            }
            else
            {
                if (fdish1.Id == 0)
                {
                    if (Food_DishBUS.chekName(txtD_Name.Text))
                    {
                        MessageBox.Show("This name is already exist!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                        txtD_Name.Clear();
                        txtD_Price.Clear();
                        txtD_Description.Clear();
                    }
                    else
                    {
                        Food_Size fsi = foodSizeBindingSource.Current as Food_Size;
                        string txtFsi = fsi.name;

                        Food_Type ftyp = foodTypeBindingSource.Current as Food_Type;
                        string txtFty = ftyp.nameType;

                        string F_D_name = txtD_Name.Text;
                        int F_D_price = int.Parse(txtD_Price.Text);
                        string F_D_description = txtD_Description.Text;

                        Food_Dish fdis = foodDishBindingSource.Current as Food_Dish;
                        string F_D_image = fdis.imaGeURL;

                        Food_DishBUS.insert(F_D_name, F_D_price, F_D_description, F_D_image, txtFty, txtFsi);
                        MessageBox.Show("Insert successfully!", "Insert dish name", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        foodDishBindingSource.DataSource = Food_DishBUS.GetAll();
                        foodDishBindingSource.MoveLast();
                        panCRUD.Enabled = true;
                        panFilter.Enabled = true;
                        panSave.Enabled = false;
                        dataGridDish.Enabled = true;
                    }

                }
                else
                {

                    int fdishID = fdish1.Id;
                    string F_D_E_Image = fdish1.imaGeURL;
                    Food_Type ftypE = foodTypeBindingSource.Current as Food_Type;
                    string txtE_Dish_typ = ftypE.nameType;

                    Food_Size fsiE = foodSizeBindingSource.Current as Food_Size;
                    string txtE_Dish_siz = fsiE.name;

                    string F_D_E_Name = txtD_Name.Text;
                    int F_D_E_Price = int.Parse(txtD_Price.Text);
                    string F_D_Description = txtD_Description.Text;

                    Food_DishBUS.edit(fdish1, F_D_E_Name, F_D_E_Price, F_D_Description, F_D_E_Image, txtE_Dish_typ, txtE_Dish_siz, fdishID);
                    MessageBox.Show("Update successfully!", "Update dish name", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    foodDishBindingSource.DataSource = Food_DishBUS.GetAll();
                    panCRUD.Enabled = true;
                    panSave.Enabled = false;
                    panFilter.Enabled = true;
                    dataGridDish.Enabled = true;
                }
            }           

        }
        private void btnDataGrid_Click(object sender, EventArgs e)
        {
            
            foodSizeBindingSource.DataSource = Food_SizeBUS.GetAll();
            foodTypeBindingSource.DataSource = Food_TypeBUS.GetAll();            
            combSizeFilter.DataSource = Food_SizeBUS.GetAll();
            combTypeFilter.DataSource = Food_TypeBUS.GetAll();
            foodDishBindingSource.DataSource = Food_DishBUS.GetAll();
        }

        private void txtD_Price_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you sure want to delete this dish ?","Waring",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)==DialogResult.Yes)
            {
                Food_Dish fdish = foodDishBindingSource.Current as Food_Dish;
                Food_DishBUS.delete(fdish);
                foodDishBindingSource.DataSource = Food_DishBUS.GetAll();
            }
            
        }

        private void dataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Food_Dish fdish = foodDishBindingSource.Current as Food_Dish;
            if (fdish.Id != 0)
            {
                int typeID = fdish.TypeId;
                int sizeID = fdish.SizeId;
                foodTypeBindingSource.DataSource = Food_TypeBUS.showType(typeID);
                foodSizeBindingSource.DataSource = Food_SizeBUS.showSize(sizeID);
				picBox.ImageLocation = @"..\..\Resources\Images\" + fdish.Id + "." + fdish.imaGeURL;

			}
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {            
            foodDishBindingSource.DataSource = Food_DishBUS.search(txtSearch.Text);
            txtSearch.Clear();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            panCRUD.Enabled = true;
            panSave.Enabled = false;
            panFilter.Enabled = true;
            dataGridDish.Enabled = true;
            foodDishBindingSource.DataSource = Food_DishBUS.GetAll();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {            
            panCRUD.Enabled = false;
            panFilter.Enabled = false;
            panSave.Enabled = true;
            dataGridDish.Enabled = false;
            foodSizeBindingSource.DataSource = Food_SizeBUS.GetAll();
            foodTypeBindingSource.DataSource = Food_TypeBUS.GetAll();
            
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "(*.jpg;*.jpeg;*.bmp;) | *.jpg;*.jpeg;*.bmp;" })
            {
                ofd.Multiselect = false;
                if(ofd.ShowDialog()==DialogResult.OK)
                {
                    picBox.Image = Image.FromFile(ofd.FileName);
                    Food_Dish fd = foodDishBindingSource.Current as Food_Dish;
                    if(fd != null)
                    {
                        fd.imaGeURL = ofd.FileName;
                    }                    
                }
            }
        }

        private void combTypeFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            int typId = int.Parse(combTypeFilter.SelectedValue.ToString());
            foodDishBindingSource.DataSource = Food_DishBUS.D_TypeFilter(typId);
        }

        private void combSizeFilter_SelectedIndexChanged(object sender, EventArgs e)
        {            
            int sizId = int.Parse(combSizeFilter.SelectedValue.ToString());
            foodDishBindingSource.DataSource = Food_DishBUS.D_SizeFilter(sizId);            
        }
    }
}
