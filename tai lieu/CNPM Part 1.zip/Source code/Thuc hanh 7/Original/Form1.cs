﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Extended
{
    public partial class Form1 : Form
    {
        private OleDbConnection connection;
        private OleDbDataAdapter adapter;
        private DataSet dataset;
        private OleDbCommand command;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0; Data Source=..\..\data\QLHOCSINH.accdb; Persist Security Info =False;";
                connection = new OleDbConnection(connectionString);
                connection.Open();

                DataTable tbLop;
                tbLop = Doc_DanhSach_Lop();
                cboLop.DataSource = tbLop;
                cboLop.DisplayMember = "Lop";
                cboLop.ValueMember = "Lop";
                dgHocsinh.ReadOnly = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTimkiem_Click(object sender, EventArgs e)
        {
            dgHocsinh.DataSource = Doc_DanhSach_HocSinh_Theo_Lop(cboLop.Text);
        }

        private DataTable Doc_DanhSach_HocSinh_Theo_Lop(string sLop)
        {
            adapter = new OleDbDataAdapter("Select MaHS as [Mã HS], HoTen as [Họ Tên],"
                                        + "GioiTinh as [Giới Tính], NgaySinh as [Ngày Sinh],"
                                        + "DTB as [Điểm TB], DiaChi as [Địa Chỉ] From HocSinh"
                                        + " Where Lop = '" + sLop + "'", connection);
            dataset = new DataSet();
            adapter.Fill(dataset);
            return dataset.Tables[0];
        }

        private DataTable Doc_DanhSach_Lop()
        {
            adapter = new OleDbDataAdapter("Select distinct LOP From HOCSINH", connection);
            dataset = new DataSet();
            adapter.Fill(dataset);
            return dataset.Tables[0];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
