﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Extended
{
    public partial class Form1 : Form
    {
        private OleDbConnection connection;
        private OleDbDataAdapter adapter;
        private DataSet dataset;
        private OleDbCommand command;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0; Data Source=..\..\data\QLHOCSINH.accdb; Persist Security Info =False;";
                connection = new OleDbConnection(connectionString);
                connection.Open();

                Fill_Combo_Lop();

                Fill_ListViewHocsinh();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (txtMaHS.Text.Trim().Length == 0)
            {
                MessageBox.Show("Vui lòng nhập Mã học sinh","Thông báo lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
                txtMaHS.Focus();
                return;
            }
            if (txtHoten.Text.Trim().Length == 0)
            {
                MessageBox.Show("Vui lòng nhập họ tên học sinh", "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtHoten.Focus();
                return;
            }
            if (txtDiachi.Text.Trim().Length == 0)
            {
                MessageBox.Show("Vui lòng nhập địa chỉ học sinh", "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDiachi.Focus();
                return;
            }
            if (txtDiemTB.Text.Trim().Length == 0)
            {
                MessageBox.Show("Vui lòng nhập ĐTB học sinh", "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDiemTB.Focus();
                return;
            }
            if (!IsValidScore(txtDiemTB.Text))
            {
                MessageBox.Show("Vui lòng nhập ĐTB học sinh từ 0 đến 10", "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDiemTB.Focus();
                return;
            }
            if (!IsValidAge(dtNgaysinh.Value))
            {
                MessageBox.Show("Vui lòng nhập tuổi học sinh từ 15 đến 20", "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDiemTB.Focus();
                return;
            }

            try
            {
                string gioiTinh = chGioiTinh.Checked ? "Nam" : "Nữ";
                string sql = "";
                if (IsExistenceStudent(txtMaHS.Text))
                {
                    sql = string.Format("UPDATE HOCSINH SET Hoten='{1}',GioiTinh='{2}',NgaySinh='{3}'," +
                                                           "Diachi='{4}',DTB = {5}, Lop='{6}' WHERE MaHS='{0}'", 
                                         txtMaHS.Text.Trim(),txtHoten.Text.Trim(), gioiTinh, dtNgaysinh.Value.ToString(), 
                                         txtDiachi.Text.Trim(), Single.Parse(txtDiemTB.Text.Trim()), cboLop.Text);
                }
                else
                {
                    sql = "INSERT INTO HOCSINH VALUES ('" + txtMaHS.Text.Trim() + "','"
                                                        + txtHoten.Text.Trim() + "','"
                                                        + gioiTinh + "','"
                                                        + dtNgaysinh.Value.ToString() + "','"
                                                        + txtDiachi.Text.Trim() + "',"
                                                        + Single.Parse(txtDiemTB.Text.Trim()) + ",'"
                                                        + cboLop.Text + "')";
                }
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                command = new OleDbCommand(sql,connection);
                command.ExecuteNonQuery();
                Fill_ListViewHocsinh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsExistenceStudent(txtMaHS.Text))
                {
                    string sql = string.Format("DELETE FROM HOCSINH WHERE MaHS='{0}'", txtMaHS.Text.Trim());
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }
                    command = new OleDbCommand(sql, connection);
                    command.ExecuteNonQuery();
                    Fill_ListViewHocsinh();
                }
                else
                {
                    MessageBox.Show("Học sinh cần xóa không tồn tại!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }

        private void btnThemmoi_Click(object sender, EventArgs e)
        {
            txtMaHS.Text = "";
            txtHoten.Text = "";
            dtNgaysinh.Value = DateTime.Today;
            chGioiTinh.Checked = false;
            txtDiachi.Text = "";
            txtDiemTB.Text = "";
        }

        private void txtMaHS_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                LoadStudentInformation(txtMaHS.Text);
            }
        }

        private void lsHocsinh_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i = lsHocsinh.FocusedItem.Index;
            if (i < 0) return;
            txtMaHS.Text = lsHocsinh.Items[i].Text;
            txtHoten.Text = lsHocsinh.Items[i].SubItems[1].Text;
            chGioiTinh.Checked = (lsHocsinh.Items[i].SubItems[2].Text.ToLower() == "nam");
            dtNgaysinh.Value = DateTime.Parse(lsHocsinh.Items[i].SubItems[3].Text);
            txtDiemTB.Text = lsHocsinh.Items[i].SubItems[4].Text;
            cboLop.Text = lsHocsinh.Items[i].SubItems[5].Text;
            txtDiachi.Text = lsHocsinh.Items[i].SubItems[6].Text;
        }

        #region support functions
        private bool IsValidScore(string score)
        {
            try
            {
                double diemTB = double.Parse(score);
                if (diemTB >= 0 && diemTB <= 10)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }

        private bool IsValidAge(DateTime birthdate)
        {
            try
            {
                int tuoi = DateTime.Today.Year - dtNgaysinh.Value.Year;

                if (tuoi >= 15 && tuoi <= 20)
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }

        private void LoadStudentInformation(string maHS)
        {
            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                string sql = "SELECT * FROM HOCSINH WHERE MAHS = '" + maHS + "'";
                command = new OleDbCommand(sql, connection);
                OleDbDataReader rdr = command.ExecuteReader();
                if(rdr.Read())
                {
                    txtHoten.Text = rdr["HoTen"].ToString();
                    chGioiTinh.Checked = rdr["GioiTinh"].ToString() == "Nam" ? true : false;
                    dtNgaysinh.Value = (DateTime)rdr["NgaySinh"];
                    txtDiachi.Text = rdr["DiaChi"].ToString();
                    txtDiemTB.Text = rdr["DTB"].ToString();
                    cboLop.SelectedValue = rdr["Lop"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }            
        }

        private bool IsExistenceStudent(string maHS)
        {
            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                string sql = "SELECT * FROM HOCSINH WHERE MAHS = '" + maHS + "'";
                command = new OleDbCommand(sql, connection);
                OleDbDataReader rdr = command.ExecuteReader();
                return rdr.HasRows;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        private void Load_Danhsach_Hocsinh_ListView(DataTable tbHocSinh)
        {
            ListViewItem item;
            lsHocsinh.Items.Clear();
            for (int i = 0; i < tbHocSinh.Rows.Count; i++)
            {
                item = lsHocsinh.Items.Add(tbHocSinh.Rows[i][0].ToString());
                for (int j = 1; j < tbHocSinh.Columns.Count; j++)
                {
                    item.SubItems.Add(tbHocSinh.Rows[i][j].ToString());
                }
            }
        }

        private DataTable Doc_DanhSach_HocSinh()
        {
            adapter = new OleDbDataAdapter("Select MaHS, Hoten, GioiTinh, NgaySinh, DTB, Lop, DiaChi From HocSinh", connection);
            dataset = new DataSet();
            adapter.Fill(dataset);
            return dataset.Tables[0];
        }

        private void Fill_Combo_Lop()
        {
            cboLop.Items.Add("Lớp 10A1");
            cboLop.Items.Add("Lớp 10A2");
            cboLop.Items.Add("Lớp 10A3");
            cboLop.Items.Add("Lớp 10A4");
            cboLop.Items.Add("Lớp 10A5");
            cboLop.SelectedIndex = 0;
        }

        private void Fill_ListViewHocsinh()
        {
            DataTable tbHocSinh;
            tbHocSinh = Doc_DanhSach_HocSinh();
            Load_Danhsach_Hocsinh_ListView(tbHocSinh);
        }
        #endregion
    }
}
