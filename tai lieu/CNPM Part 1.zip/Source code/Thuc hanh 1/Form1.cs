﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Thuchanh1
{
    public partial class frmTinhTong : Form
    {
        public frmTinhTong()
        {
            InitializeComponent();
        }

        private void btnTinhTong_Click(object sender, EventArgs e)
        {
            try
            {
                int sohang1 = Int32.Parse(txtSohang1.Text);
                int sohang2 = Int32.Parse(txtSohang2.Text);
                int ketqua;

                if (rdbCong.Checked)
                {
                    ketqua = sohang1 + sohang2;
                }
                else if (rdbTru.Checked)
                {
                    ketqua = sohang1 - sohang2;
                }
                else if (rdbNhan.Checked)
                {
                    ketqua = sohang1 * sohang2;
                }

                else
                {
                    ketqua = sohang1 / sohang2;
                }

                txtTong.Text = ketqua.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmTinhTong_Load(object sender, EventArgs e)
        {
            this.Text = "Thu nghiem";
            txtTong.ReadOnly = true;
        }

    }
}
