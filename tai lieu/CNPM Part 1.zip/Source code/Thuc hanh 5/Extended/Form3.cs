﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Extended
{
    public partial class Form3 : Form
    {
        private OleDbConnection connection;
        private OleDbDataAdapter adapter;
        private DataSet dataset;
        private OleDbCommand command;

        public Form3()
        {
            InitializeComponent();
        }

        #region even-handlers
        private void Form3_Load(object sender, EventArgs e)
        {
            try
            {
                string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" + Form2.sDuongdan + "; Persist Security Info =False;";
                connection = new OleDbConnection(connectionString);
                connection.Open();

                Fill_ListViewLop();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lvLop_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i = lvLop.FocusedItem.Index;
            if (i < 0) return;
            txtTenlop.Text = lvLop.Items[i].Text;
            txtMota.Text = lvLop.Items[i].SubItems[1].Text;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            txtTenlop.Text = "";
            txtMota.Text = "";
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (!ValidateInfo()) return;
            try
            {
                string sql = "";
                if (IsExistenceLop(txtTenlop.Text))
                {
                    sql = string.Format("UPDATE LOP SET Mota='{1}' WHERE TenLop = {0}", txtTenlop.Text.Trim(), txtMota.Text.Trim());
                }
                else
                {
                    sql = string.Format("INSERT INTO LOP VALUES ('{0}', '{1}')",txtTenlop.Text.Trim(), txtMota.Text.Trim());
                }
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                command = new OleDbCommand(sql, connection);
                command.ExecuteNonQuery();
                Fill_ListViewLop();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }

        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsExistenceLop(txtTenlop.Text))
                {
                    string sql = string.Format("DELETE FROM LOP WHERE Tenlop='{0}'", txtTenlop.Text);
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }
                    command = new OleDbCommand(sql, connection);
                    command.ExecuteNonQuery();
                    Fill_ListViewLop();
                }
                else
                {
                    MessageBox.Show("Học sinh cần xóa không tồn tại!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

        #region support funtions
        private bool ValidateInfo()
        {
            if (txtTenlop.Text.Trim().Length == 0)
            {
                MessageBox.Show("Vui lòng nhập Mã Lớp", "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTenlop.Focus();
                return false;
            }
            if (txtMota.Text.Trim().Length == 0)
            {
                MessageBox.Show("Vui lòng nhập Mô tả", "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMota.Focus();
                return false;
            }
            return true;
        }

        private bool IsExistenceLop(string tenlop)
        {
            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                string sql = string.Format("SELECT * FROM LOP WHERE TenLop = '{0}'", tenlop);
                command = new OleDbCommand(sql, connection);
                OleDbDataReader rdr = command.ExecuteReader();
                return rdr.HasRows;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        private void Fill_ListViewLop()
        {
            DataTable tbHocSinh;
            tbHocSinh = Doc_DanhSach_Lop();
            Load_Danhsach_Lop_ListView(tbHocSinh);
        }

        private DataTable Doc_DanhSach_Lop()
        {
            adapter = new OleDbDataAdapter("Select * From LOP", connection);
            dataset = new DataSet();
            adapter.Fill(dataset);
            return dataset.Tables[0];
        }

        private void Load_Danhsach_Lop_ListView(DataTable tblLop)
        {
            ListViewItem item;
            lvLop.Items.Clear();
            for (int i = 0; i < tblLop.Rows.Count; i++)
            {
                item = lvLop.Items.Add(tblLop.Rows[i][0].ToString());
                for (int j = 1; j < tblLop.Columns.Count; j++)
                {
                    item.SubItems.Add(tblLop.Rows[i][j].ToString());
                }
            }
        }
        #endregion
    }
}
