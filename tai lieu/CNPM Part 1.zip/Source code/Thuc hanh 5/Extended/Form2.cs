﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Extended
{
    public partial class Form2 : Form
    {
        public static string sDuongdan = @"..\..\data\QLHOCSINH.accdb";

        public Form2()
        {
            InitializeComponent();
        }

        private void btnOpenFile_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "File (*.accdb)|*.accdb";
            openFileDialog1.Multiselect = false;
            openFileDialog1.Title = "Chọn CSDL";
            openFileDialog1.FileName = "QLHOCSINH.accdb";
            DialogResult dgResult = openFileDialog1.ShowDialog();
            if (dgResult == DialogResult.OK)
            {
                txtFile.Text = openFileDialog1.FileName;
            }
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (txtFile.Text.Trim().Length == 0)
            {
                MessageBox.Show("Chưa chọn đường dẫn và tên CSDL", "Thông báo lỗi");
                return;
            }
            sDuongdan = txtFile.Text.Trim();
            this.Hide();
            Form1 frmHocsinh = new Form1();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
