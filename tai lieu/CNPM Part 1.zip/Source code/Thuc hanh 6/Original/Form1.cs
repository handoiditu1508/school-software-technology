﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Extended
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void tvChucnang_AfterSelect(object sender, TreeViewEventArgs e)
        {
            switch (e.Node.Text.ToLower())
            {
                case "quản trị hệ thống":
                    lvChucnang.Items.Clear();
                    lvChucnang.Items.Add("Đăng nhập hệ thống", 4);
                    lvChucnang.Items.Add("Đăng xuất hệ thống", 5);
                    break;
                case "quản lý hồ sơ học sinh":
                    lvChucnang.Items.Clear();
                    lvChucnang.Items.Add("Tiếp nhận học sinh mới", 4);
                    lvChucnang.Items.Add("Tìm kiếm hồ sơ học sinh", 6);
                    break;
            }

        }

        private void lvChucnang_DoubleClick(object sender, EventArgs e)
        {
            string ItemName = lvChucnang.SelectedItems[0].Text;
            switch (ItemName.ToLower())
            {
                case "tiếp nhận học sinh mới":
                    break;
                case "tìm kiếm hồ sơ học sinh":
                    break;
            }
        }
    }
}
