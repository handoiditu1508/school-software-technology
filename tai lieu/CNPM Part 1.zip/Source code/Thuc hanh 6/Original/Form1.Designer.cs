﻿namespace Extended
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Quản trị hệ thống", 1, 1);
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Quản lý hồ sơ học sinh", 2, 2);
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Trợ giúp", 3, 3);
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Quản lý học sinh", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3});
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngnhậpHệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngxuấtHệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.thoátchươngTrìnhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hồsơToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tiếpNhậnHọcSinhMớiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmKiếmHọcSinhToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tvChucnang = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.lvChucnang = new System.Windows.Forms.ListView();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hệThốngToolStripMenuItem,
            this.hồsơToolStripMenuItem,
            this.trợGiúpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(774, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hệThốngToolStripMenuItem
            // 
            this.hệThốngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.đăngnhậpHệThốngToolStripMenuItem,
            this.đăngxuấtHệThốngToolStripMenuItem,
            this.toolStripMenuItem2,
            this.thoátchươngTrìnhToolStripMenuItem});
            this.hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            this.hệThốngToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.hệThốngToolStripMenuItem.Text = "&Hệ thống";
            // 
            // đăngnhậpHệThốngToolStripMenuItem
            // 
            this.đăngnhậpHệThốngToolStripMenuItem.Name = "đăngnhậpHệThốngToolStripMenuItem";
            this.đăngnhậpHệThốngToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.đăngnhậpHệThốngToolStripMenuItem.Text = "Đăng &nhập hệ thống";
            // 
            // đăngxuấtHệThốngToolStripMenuItem
            // 
            this.đăngxuấtHệThốngToolStripMenuItem.Name = "đăngxuấtHệThốngToolStripMenuItem";
            this.đăngxuấtHệThốngToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.đăngxuấtHệThốngToolStripMenuItem.Text = "Đăng &xuất  hệ thống";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(180, 6);
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // thoátchươngTrìnhToolStripMenuItem
            // 
            this.thoátchươngTrìnhToolStripMenuItem.Name = "thoátchươngTrìnhToolStripMenuItem";
            this.thoátchươngTrìnhToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.thoátchươngTrìnhToolStripMenuItem.Text = "Thoát &chương trình";
            // 
            // hồsơToolStripMenuItem
            // 
            this.hồsơToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tiếpNhậnHọcSinhMớiToolStripMenuItem,
            this.tìmKiếmHọcSinhToolStripMenuItem});
            this.hồsơToolStripMenuItem.Name = "hồsơToolStripMenuItem";
            this.hồsơToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.hồsơToolStripMenuItem.Text = "Hồ &sơ";
            // 
            // tiếpNhậnHọcSinhMớiToolStripMenuItem
            // 
            this.tiếpNhậnHọcSinhMớiToolStripMenuItem.Name = "tiếpNhậnHọcSinhMớiToolStripMenuItem";
            this.tiếpNhậnHọcSinhMớiToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.tiếpNhậnHọcSinhMớiToolStripMenuItem.Text = "Tiếp  nhận học sinh mới";
            // 
            // tìmKiếmHọcSinhToolStripMenuItem
            // 
            this.tìmKiếmHọcSinhToolStripMenuItem.Name = "tìmKiếmHọcSinhToolStripMenuItem";
            this.tìmKiếmHọcSinhToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.tìmKiếmHọcSinhToolStripMenuItem.Text = "Tìm kiếm học sinh";
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.trợGiúpToolStripMenuItem.Text = "&Trợ giúp";
            // 
            // tvChucnang
            // 
            this.tvChucnang.ImageIndex = 0;
            this.tvChucnang.ImageList = this.imageList1;
            this.tvChucnang.Location = new System.Drawing.Point(12, 27);
            this.tvChucnang.Name = "tvChucnang";
            treeNode1.ImageIndex = 1;
            treeNode1.Name = "Node2";
            treeNode1.SelectedImageIndex = 1;
            treeNode1.Text = "Quản trị hệ thống";
            treeNode2.ImageIndex = 2;
            treeNode2.Name = "Node3";
            treeNode2.SelectedImageIndex = 2;
            treeNode2.Text = "Quản lý hồ sơ học sinh";
            treeNode3.ImageIndex = 3;
            treeNode3.Name = "Node4";
            treeNode3.SelectedImageIndex = 3;
            treeNode3.Text = "Trợ giúp";
            treeNode4.Name = "Node0";
            treeNode4.SelectedImageIndex = 0;
            treeNode4.Text = "Quản lý học sinh";
            this.tvChucnang.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode4});
            this.tvChucnang.SelectedImageIndex = 0;
            this.tvChucnang.Size = new System.Drawing.Size(264, 352);
            this.tvChucnang.TabIndex = 1;
            this.tvChucnang.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvChucnang_AfterSelect);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "time_management.png");
            this.imageList1.Images.SetKeyName(1, "system_config_services.png");
            this.imageList1.Images.SetKeyName(2, "folder_open.png");
            this.imageList1.Images.SetKeyName(3, "dialog_question.png");
            this.imageList1.Images.SetKeyName(4, "login (1).png");
            this.imageList1.Images.SetKeyName(5, "application_exit.png");
            this.imageList1.Images.SetKeyName(6, "user_group_new.png");
            // 
            // lvChucnang
            // 
            this.lvChucnang.LargeImageList = this.imageList1;
            this.lvChucnang.Location = new System.Drawing.Point(283, 28);
            this.lvChucnang.Name = "lvChucnang";
            this.lvChucnang.Size = new System.Drawing.Size(479, 351);
            this.lvChucnang.TabIndex = 2;
            this.lvChucnang.UseCompatibleStateImageBehavior = false;
            this.lvChucnang.DoubleClick += new System.EventHandler(this.lvChucnang_DoubleClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(774, 391);
            this.Controls.Add(this.lvChucnang);
            this.Controls.Add(this.tvChucnang);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Chương trình quản lý học sinh";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngnhậpHệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngxuấtHệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátchươngTrìnhToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hồsơToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem tiếpNhậnHọcSinhMớiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmKiếmHọcSinhToolStripMenuItem;
        private System.Windows.Forms.TreeView tvChucnang;
        private System.Windows.Forms.ListView lvChucnang;
        private System.Windows.Forms.ImageList imageList1;
    }
}

