﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Thuchanh2
{
    public partial class frmThucdon : Form
    {
        public frmThucdon()
        {
            InitializeComponent();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                listThucdon.Items.Add(textMon.Text);
                textMon.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (var item in listThucdon.SelectedItems)
                {
                    if (!listChon.Items.Contains(item))
                    {
                        listChon.Items.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

        }

        private void btnAddAll_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (var item in listThucdon.Items)
                {
                    if (!listChon.Items.Contains(item))
                    {
                        listChon.Items.Add(item);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            try
            {
                int count = listChon.SelectedItems.Count;
                for (int i = count - 1; i >= 0; i--)
                {
                    listChon.Items.Remove(listChon.SelectedItems[i]);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnRemoveAll_Click(object sender, EventArgs e)
        {
            try
            {
                listChon.Items.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
