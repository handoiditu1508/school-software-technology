﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Extended
{
    public partial class Form1 : Form
    {
        private OleDbConnection connection;
        private OleDbDataAdapter adapter;
        private DataSet dataset;
        private OleDbCommand command;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0; Data Source=..\..\data\QLHOCSINH.accdb; Persist Security Info =False;";
                connection = new OleDbConnection(connectionString);
                connection.Open();

                cboLop.Items.Add("Lớp 10A1");
                cboLop.Items.Add("Lớp 10A2");
                cboLop.Items.Add("Lớp 10A3");
                cboLop.Items.Add("Lớp 10A4");
                cboLop.Items.Add("Lớp 10A5");
                cboLop.SelectedIndex = 0;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (txtMaHS.Text.Trim().Length == 0)
            {
                MessageBox.Show("Vui lòng nhập Mã học sinh","Thông báo lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
                txtMaHS.Focus();
                return;
            }
            if (txtHoten.Text.Trim().Length == 0)
            {
                MessageBox.Show("Vui lòng nhập họ tên học sinh", "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtHoten.Focus();
                return;
            }
            if (txtDiachi.Text.Trim().Length == 0)
            {
                MessageBox.Show("Vui lòng nhập địa chỉ học sinh", "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDiachi.Focus();
                return;
            }
            if (txtDiemTB.Text.Trim().Length == 0)
            {
                MessageBox.Show("Vui lòng nhập ĐTB học sinh", "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDiemTB.Focus();
                return;
            }

            try
            {
                string gioiTinh = chGioiTinh.Checked ? "Nam" : "Nữ";
                string sql = "INSERT INTO HOCSINH VALUES ('" + txtMaHS.Text.Trim() + "','"
                                                        + txtHoten.Text.Trim() + "','"
                                                        + gioiTinh + "','"
                                                        + dtNgaysinh.Value.ToString() + "','"
                                                        + txtDiachi.Text.Trim() + "',"
                                                        + Single.Parse(txtDiemTB.Text.Trim()) + ",'"
                                                        + cboLop.Text + "')";
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                command = new OleDbCommand(sql,connection);
                command.ExecuteNonQuery();
                MessageBox.Show("Lưu dữ liệu thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            txtMaHS.Text = "";
            txtHoten.Text="";
            dtNgaysinh.Value = DateTime.Today;
            chGioiTinh.Checked = false;
            txtDiachi.Text="";
            txtDiemTB.Text = "";
        }

        private bool IsExistenceStudent(string maHS)
        {
            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                string sql = "SELECT * FROM HOCSINH WHERE MAHS = '" + maHS + "'";
                command = new OleDbCommand(sql, connection);
                OleDbDataReader rdr = command.ExecuteReader();
                return rdr.HasRows;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

    }
}
