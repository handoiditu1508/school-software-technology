﻿using seLibrary.Model.BookTitles;
using seLibrary.Model.Members;
using seLibrary.Model.Repositories;
using System;
using System.Collections.Generic;

namespace seLibrary.Persistence.ADO
{
    public class MemberRepository : IMemberRepository
    {
        public void Delete(Member entity)
        {
            throw new NotImplementedException();
        }

        public IList<Member> FindAll()
        {
            throw new NotImplementedException();
        }

        public Member FindBy(int id)
        {
            throw new NotImplementedException();
        }

        public void Save(Member member)
        {
            throw new NotImplementedException();
        }
    }
}
