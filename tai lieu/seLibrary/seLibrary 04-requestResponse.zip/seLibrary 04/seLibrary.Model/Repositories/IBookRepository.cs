﻿using seLibrary.Infrastructure;
using seLibrary.Model.Books;
using seLibrary.Model.BookTitles;
using System.Collections.Generic;

namespace seLibrary.Model.Repositories
{
    public interface IBookRepository : IRepository<Book>
    {
    }
}
