﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using seLibrary.Model.Books;
using seLibrary.Model.Members;
using seLibrary.Model.Repositories;

namespace seLibrary.Model.Services
{
    public class LoanService
    {
        private IBookRepository bookRepository;
        private IMemberRepository memberRepository;

        public LoanService(IBookRepository bookRepository, IMemberRepository memberRepository)
        {
            this.bookRepository = bookRepository;
            this.memberRepository = memberRepository;
        }

        public Loan Loan(int bookId, int memberId) 
        {
            Loan loan = default(Loan);

            Book book = bookRepository.FindBy(bookId);
            Member member = memberRepository.FindBy(memberId);

            if (member.CanLoan(book))
            {
                loan = member.Loan(book);
                memberRepository.Save(member);
                bookRepository.Save(book);
            }

            return loan;
        }

        public void Return(Book book)
        {
            Member member = book.OnLoanTo;
            member.Return(book);
            memberRepository.Save(member);
            bookRepository.Save(book);
        }
    }
}
