﻿using seLibrary.Model.Books;
using System;

namespace seLibrary.Model.Members
{
    public class Loan
    {
        public int ID { get; set; }
        public virtual Book Book { get; set; }
        public DateTime? LoanDate { get; set; }
        public DateTime? ReturnDate { get; set; }
        public DateTime? DateForReturn { get; set; }
        public virtual Member Member { get; set; }
        public bool HasNotBeenReturned()
        {
            return ReturnDate == null;
        }
    }
}