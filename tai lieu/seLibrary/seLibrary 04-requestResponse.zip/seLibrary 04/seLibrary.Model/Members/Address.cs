﻿namespace seLibrary.Model.Members
{
    public class Address
    {
        public Address() { }
        public Address(string number, string street, string ward, string district, string city)
        {
            Number = number;
            Street = street;
            Ward = ward;
            District = district;
            City = city;
        }
        public string Number { get; private set; } 
        public string Street { get; private set; }
        public string Ward { get; private set; }
        public string District { get; private set; }
        public string City { get; private set; }
    }
}