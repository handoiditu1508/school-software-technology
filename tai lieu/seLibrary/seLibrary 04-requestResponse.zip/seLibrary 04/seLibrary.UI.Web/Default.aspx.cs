﻿using seLibrary.Application;
using seLibrary.Application.Messages;
using System;
using System.Configuration;

namespace seLibrary.UI.Web
{
    public partial class Default : System.Web.UI.Page
    {
        private LibraryService libService;

        protected void Page_Load(object sender, EventArgs e)
        {
            libService = ServiceFactory.GetLibraryService(ConfigurationManager.AppSettings["PeristenceStrategy"]);
            DisplayMembers();
            DisplayBooks();
            DisplayBookTitles();

        }

        protected void btnAddMember_Click(object sender, EventArgs e)
        {
            AddMemberRequest request = new AddMemberRequest()
            {
                 FirstName= txtFirstName.Text,
                  LastName= txtLastName.Text
            };
            libService.AddMember(request);
            DisplayMembers();
            DisplayBookTitles();
        }

        protected void btnAddBook_Click(object sender, EventArgs e)
        {
            libService.AddBook(new AddBookRequest() { BookId = ddlBookTitle.SelectedValue });
            DisplayMembers();
            DisplayBooks();
            DisplayBookTitles();
        }

        protected void btnAddTitle_Click(object sender, EventArgs e)
        {
            libService.AddTitle(new AddTitleRequest() { ISBN = txtISBN.Text, Title = txtTitle.Text });
            DisplayMembers();
            DisplayBooks();
            DisplayBookTitles();
        }

        private void DisplayMembers()
        {
            FindMemberResponse response = libService.FindMembers();
            rptMembers.DataSource = response.MembersFound;
            rptMembers.DataBind();
        }

        private void DisplayBooks() 
        {
            FindBookResponse response = libService.FindBooks();
            ddlBookTitle.DataSource = response.Books;
            ddlBookTitle.DataTextField = "Title";
            ddlBookTitle.DataValueField = "BookId";
            ddlBookTitle.DataBind();

            FindBookResponse bookResponse = libService.FindBooks();
            rptBooks.DataSource = bookResponse.Books;
            rptBooks.DataBind();
        }

        private void DisplayBookTitles()
        {
            FindBookTitleResponse response = libService.FindBookTitles();
            rptBookTitles.DataSource = response.BookTitles;
            rptBookTitles.DataBind();
        }

    }
}