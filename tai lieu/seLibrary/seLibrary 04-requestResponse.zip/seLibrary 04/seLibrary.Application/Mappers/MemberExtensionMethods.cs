﻿using seLibrary.Application.Views;
using seLibrary.Model.Members;
using System;
using System.Collections.Generic;

namespace seLibrary.Application.Mappers
{
    public static class MemberExtensionMethods
    {
        public static string Fullname(this Member member)
        {
            return (member == null) ? string.Empty : (member.FirstName + member.LastName);
        }

        public static MemberView ConvertToMemberView(this Member member)
        {
            MemberView memberView = new MemberView()
            {
                MemberId = member.ID,
                FullName = member.FirstName + " " + member.LastName,
                Loans = GenerateLoanViewFrom(member.Loans)
            };
            return memberView;
        }

        public static IEnumerable<MemberView> ConvertToMemberViews(this ICollection<Member> members)
        {
            foreach (Member member in members)
            {
                yield return member.ConvertToMemberView();
            }
        }
        private static IEnumerable<LoanView> GenerateLoanViewFrom(IEnumerable<Loan> loans)
        {
            foreach (var loan in loans)
            {
                yield return loan.ConvertToLoanView();
            }
        }
    }
}
