﻿using seLibrary.Application.Views;
using seLibrary.Model.Books;
using seLibrary.Model.Members;
using System.Collections.Generic;

namespace seLibrary.Application.Mappers
{
    public static class BookExtensionMethods
    {
        public static BookView ConvertToBookView(this Book book)
        {
            return new BookView()
            {
                BookId = book.ID,
                ISBN = book.BookTitle.ISBN,
                Title = book.BookTitle.Title,
                OnLoanTo = book.OnLoanTo.Fullname()
            };
        }

        public static IEnumerable<BookView> ConvertToBookViews(this IEnumerable<Book> books)
        {
            foreach(Book book in books)
            {
                yield return book.ConvertToBookView();
            }
        }
    }
}