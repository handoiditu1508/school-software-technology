﻿using seLibrary.Application.Views;
using seLibrary.Model.BookTitles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seLibrary.Application.Mappers
{
    public static class BookTitleExtensionMethods
    {
        public static BookTitleView ConvertToBookTitleView(this BookTitle bookTitle)
        {
            return new BookTitleView()
            {
                ID = bookTitle.ID.ToString(),
                ISBN = bookTitle.ISBN,
                Title = bookTitle.Title
            };
        }

        public static IEnumerable<BookTitleView> ConvertToBookTitleViews(this IEnumerable<BookTitle> bookTitles)
        {
            foreach (BookTitle bookTitle in bookTitles)
            {
                yield return bookTitle.ConvertToBookTitleView();
            }
        }
    }
}
