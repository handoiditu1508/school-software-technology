﻿namespace seLibrary.Application.Messages
{
    public class AddBookRequest
    {
        public string BookId { get; set; }
    }
}
