﻿using seLibrary.Application.Views;
using System.Collections.Generic;

namespace seLibrary.Application.Messages
{
    public class FindBookResponse : ResponseBase
    {
        public IEnumerable<BookView> Books { get; set; }
    }
}
