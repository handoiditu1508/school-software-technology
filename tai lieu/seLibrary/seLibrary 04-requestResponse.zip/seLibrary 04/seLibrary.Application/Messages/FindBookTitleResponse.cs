﻿using seLibrary.Application.Views;
using System.Collections.Generic;

namespace seLibrary.Application.Messages
{
    public class FindBookTitleResponse : ResponseBase
    {
        public IEnumerable<BookTitleView> BookTitles { get; set; }
    }
}
