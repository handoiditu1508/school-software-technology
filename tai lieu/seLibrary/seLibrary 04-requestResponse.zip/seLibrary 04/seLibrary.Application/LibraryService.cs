﻿using seLibrary.Application.Mappers;
using seLibrary.Application.Messages;
using seLibrary.Application.Views;
using seLibrary.Infrastructure.Helpers;
using seLibrary.Model.Books;
using seLibrary.Model.BookTitles;
using seLibrary.Model.Members;
using seLibrary.Model.Repositories;
using seLibrary.Model.Services;
using System.Collections.Generic;

namespace seLibrary.Application
{
    public class LibraryService
    {
        private IMemberRepository memberRepository;
        private IBookRepository bookRepository;
        private IBookTitleRepository bookTitleRepository;
        private LoanService loanService;

        public LibraryService(IMemberRepository memberRepository, IBookRepository bookRepository, IBookTitleRepository bookTitleRepository)
        {
            this.memberRepository = memberRepository;
            this.bookRepository = bookRepository;
            this.bookTitleRepository = bookTitleRepository;
            loanService = new LoanService(bookRepository, memberRepository);
        }

        public void LoanBook(string bookId, string memberId)
        {
            loanService.Loan(bookId.ToInt(), memberId.ToInt());
        }

        public void Return(string bookId)
        {
            Book book = bookRepository.FindBy(bookId.ToInt());
            loanService.Return(book);
        }

        #region Members
        public FindMemberResponse FindMembers(FindMemberRequest request = null)
        {
            IEnumerable <MemberView> members = new List<MemberView>();

            if (request == null || request.All)
            {
                members = memberRepository.FindAll().ConvertToMemberViews();
            }
            else
            {
                Member member = memberRepository.FindBy(request.MemberId.ToInt());
                members = new List<MemberView> { member.ConvertToMemberView() };
            }

            return new FindMemberResponse()
            {
                MembersFound = members,
                Success = true
            };
        }

        public void AddMember(AddMemberRequest request)
        {
            Member member = new Member()
            {
                FirstName = request.FirstName,
                LastName = request.LastName
            };
            memberRepository.Save(member);
        }
        #endregion

        #region BookTitles
        public FindBookTitleResponse FindBookTitles(FindBookTitleRequest request = null)
        {
            IEnumerable<BookTitleView> bookTitles = new List<BookTitleView>();
            if (request == null || request.All)
            {
                bookTitles = bookTitleRepository.FindAll().ConvertToBookTitleViews();

            }
            return new FindBookTitleResponse
            {
                BookTitles = bookTitles,
                Success = true
            };
        }
        public void AddTitle(AddTitleRequest request)
        {
            BookTitle bookTitle = new BookTitle()
            {
                ISBN = request.ISBN,
                Title = request.Title
            };
            bookTitleRepository.Save(bookTitle);
        }

        #endregion

        #region Books
        public FindBookResponse FindBooks(FindBookRequest request = null)
        {
            IEnumerable<BookView> books = new List<BookView>();
            if (request == null || request.All)
            {
                books = bookRepository.FindAll().ConvertToBookViews();
            }
            return new FindBookResponse
            {
                Books = books,
                Success = true
            };
        }

        public void AddBook(AddBookRequest request)
        {
            Book book = new Book()
            {
                BookTitle = bookTitleRepository.FindBy(request.BookId.ToInt())
            };
            bookRepository.Save(book);
        }
        #endregion

    }
}
