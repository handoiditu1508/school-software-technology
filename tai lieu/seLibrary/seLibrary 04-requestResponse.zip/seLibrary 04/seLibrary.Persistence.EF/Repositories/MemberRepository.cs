﻿using seLibrary.Model.Members;
using seLibrary.Model.Repositories;
using System.Collections.Generic;
using System.Linq;

namespace seLibrary.Persistence.EF.Repositories
{
    public class MemberRepository : IMemberRepository
    {
        private LibraryContext LibraryDB
        {
            get { return LibraryContext.Instance; }
        }

        public void Delete(Member entity)
        {
            LibraryDB.Members.Remove(entity);
            LibraryDB.SaveChanges();
        }

        public IList<Member> FindAll()
        {
            return LibraryDB.Members.ToList();
        }

        public Member FindBy(int id)
        {
            return LibraryDB.Members.FirstOrDefault(m => m.ID == id);
        }

        public void Save(Member member)
        {
            if (!LibraryDB.Members.Any(b => b.ID == member.ID))
            {
                LibraryDB.Members.Add(member);
            }
            LibraryDB.SaveChanges();
        }
    }
}
