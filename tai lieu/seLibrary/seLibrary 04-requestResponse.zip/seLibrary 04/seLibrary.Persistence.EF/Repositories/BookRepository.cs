﻿using seLibrary.Model.Books;
using seLibrary.Model.BookTitles;
using seLibrary.Model.Members;
using seLibrary.Model.Repositories;
using System.Collections.Generic;
using System.Linq;

namespace seLibrary.Persistence.EF.Repositories
{
    public class BookRepository : IBookRepository
    {
        private LibraryContext LibraryDB
        {
            get { return LibraryContext.Instance; }
        }
        public IList<Book> FindAll()
        {
            return LibraryDB.Books.ToList();
        }
        public Book FindBy(int id)
        {
            return LibraryDB.Books.FirstOrDefault(m => m.ID == id);
        }
        public void Save(Book entity)
        {
            if (!LibraryDB.Books.Any(b => b.ID == entity.ID))
            {
                LibraryDB.Books.Add(entity);
            }
            LibraryDB.SaveChanges();
        }
        public void Delete(Book entity)
        {
            LibraryDB.Books.Remove(entity);
            LibraryDB.SaveChanges();
        }
    }
}
