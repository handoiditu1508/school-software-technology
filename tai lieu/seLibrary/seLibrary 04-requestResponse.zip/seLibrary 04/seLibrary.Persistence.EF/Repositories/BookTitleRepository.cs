﻿using System.Collections.Generic;
using System.Linq;
using seLibrary.Model.BookTitles;
using seLibrary.Model.Repositories;

namespace seLibrary.Persistence.EF.Repositories
{
    public class BookTitleRepository : IBookTitleRepository
    {
        private LibraryContext LibraryDB
        {
            get { return LibraryContext.Instance; }
        }
        public void Delete(BookTitle entity)
        {
            throw new System.NotImplementedException();
        }

        public IList<BookTitle> FindAll()
        {
            return LibraryDB.BookTitles.ToList();
        }

        public BookTitle FindBy(int id)
        {
            return LibraryDB.BookTitles.FirstOrDefault(t => t.ID == id);
        }

        public void Save(BookTitle entity)
        {
            LibraryDB.BookTitles.Add(entity);
            LibraryDB.SaveChanges();
        }
    }
}
