﻿using seLibrary.Model.Books;
using seLibrary.Model.BookTitles;
using seLibrary.Model.Members;
using System.Data.Entity;

namespace seLibrary.Persistence.EF
{
    public class LibraryContext : DbContext
    {
        private static LibraryContext libContext;
        public static LibraryContext Instance
        {
            get
            {
                if (libContext == null)
                {
                    libContext = new LibraryContext();
                }
                return libContext;
            }
        }
        private LibraryContext() : base("LibraryContext")
        {
        }
        public DbSet<Member> Members { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<BookTitle> BookTitles { get; set; }
    }
}
