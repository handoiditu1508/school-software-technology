﻿using seLibrary.Application.Mappers;
using seLibrary.Application.Views;
using seLibrary.Infrastructure.Helpers;
using seLibrary.Model.Books;
using seLibrary.Model.BookTitles;
using seLibrary.Model.Members;
using seLibrary.Model.Repositories;
using seLibrary.Model.Services;
using System;
using System.Collections.Generic;

namespace seLibrary.Application
{
    public class LibraryService
    {
        private IMemberRepository memberRepository;
        private IBookRepository bookRepository;
        private IBookTitleRepository bookTitleRepository;

        //private IBookRepository bookRepository;
        private LoanService loanService;

        public LibraryService(IMemberRepository memberRepository, IBookRepository bookRepository, IBookTitleRepository bookTitleRepository)
        {
            this.memberRepository = memberRepository;
            this.bookRepository = bookRepository;
            this.bookTitleRepository = bookTitleRepository;
            loanService = new LoanService(bookRepository, memberRepository);
        }

        public void LoanBook(string bookId, string memberId)
        {
            loanService.Loan(bookId.ToInt(), memberId.ToInt());
        }


        #region Members
        public IEnumerable<Member> FindMembers()
        {
            return memberRepository.GetAll();
        }
        public MemberView FindMember(string memberId)  
        {
            return memberRepository.GetBy(memberId.ToInt()).ConvertToMemberView();
        }
        public void AddMember(string firstName, string lastName)
        {
            Member member = new Member()
            {
                FirstName = firstName,
                LastName = lastName
            };
            memberRepository.Save(member);
        }
        public IEnumerable<BookTitle> FindBookTitles()
        {
            return bookTitleRepository.GetAll();
        }
        #endregion

        #region Books
        public IEnumerable<BookView> FindBooks()
        {
            return bookRepository.GetAll().ConvertToBookViews();
        }
        public void AddBook(string bookTitleID)
        {
            Book book = new Book()
            {
                 BookTitle = bookTitleRepository.GetBy(bookTitleID.ToInt())
            };
            bookRepository.Save(book);
        }

        public void AddTitle(string isbn, string title)
        {
            BookTitle bookTitle = new BookTitle()
            {
                ISBN = isbn,
                Title = title
            };
            bookTitleRepository.Save(bookTitle);
        }

        #endregion

    }
}
