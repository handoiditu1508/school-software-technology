﻿using seLibrary.Model.Repositories;

namespace seLibrary.Persistence.EF.Repositories
{
    public class BookTitleRepository1 
    {
    }
}