﻿using seLibrary.Application.Views;
using seLibrary.Model.Members;
using System;
using System.Collections.Generic;

namespace seLibrary.Application.Mappers
{
    public static class MemberExtensionMethods
    {
        public static string Fullname(this Member member)
        {
            return (member == null) ? string.Empty : (member.FirstName + member.LastName);
        }

        public static MemberView ConvertToMemberView(this Member member)
        {
            return new MemberView()
            {
                MemberId=member.ID,
                FullName=member.FirstName + " " + member.LastName,
                Loans = GenerateLoanViewFrom(member.Loans)
            };
        }

        public static IEnumerable<MemberView> ConvertToMemberViews(this IEnumerable<Member> members)
        {
            foreach (Member member in members)
            {
                yield return member.ConvertToMemberView();
            }
        }
        private static IEnumerable<LoanView> GenerateLoanViewFrom(ICollection<Loan> loans)
        {
            foreach(var loan in loans)
            {
                yield return loan.ConvertToLoanView(); 
            }
        }
    }
}
