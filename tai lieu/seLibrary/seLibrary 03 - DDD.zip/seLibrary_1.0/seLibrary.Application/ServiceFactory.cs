﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seLibrary.Application
{
    public class ServiceFactory
    {
        public static LibraryService GetLibraryService(string persistenceStrategy)
        {
            if (persistenceStrategy == "EF")
            {
                return new LibraryService(new Persistence.EF.Repositories.MemberRepository(),
                                          new Persistence.EF.Repositories.BookRepository(),
                                          new Persistence.EF.Repositories.BookTitleRepository());
            }
            if (persistenceStrategy == "ADO")
            {
                return new LibraryService(new Persistence.ADO.MemberRepository(), null, null);
            }
            return null;
        }
    }
}
