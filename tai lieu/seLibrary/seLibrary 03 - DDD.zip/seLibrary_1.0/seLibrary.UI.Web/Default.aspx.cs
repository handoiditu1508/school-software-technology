﻿using seLibrary.Application;
using System;
using System.Configuration;

namespace seLibrary.UI.Web
{
    public partial class Default : System.Web.UI.Page
    {
        private LibraryService libService;

        protected void Page_Load(object sender, EventArgs e)
        {
            libService = ServiceFactory.GetLibraryService(ConfigurationManager.AppSettings["PeristenceStrategy"]);
            DisplayMembers();
            DisplayBooks();
            DisplayBookTitles();

        }

        protected void btnAddMember_Click(object sender, EventArgs e)
        {
            libService.AddMember(txtFirstName.Text, txtLastName.Text);
            DisplayMembers();
            DisplayBookTitles();
        }

        protected void btnAddBook_Click(object sender, EventArgs e)
        {
            libService.AddBook(ddlBookTitle.SelectedValue);
            DisplayMembers();
            DisplayBooks();
            DisplayBookTitles();
        }

        protected void btnAddTitle_Click(object sender, EventArgs e)
        {
            libService.AddTitle(txtISBN.Text, txtTitle.Text);
            DisplayMembers();
            DisplayBooks();
            DisplayBookTitles();
        }

        private void DisplayMembers()
        {
            rptMembers.DataSource = libService.FindMembers();
            rptMembers.DataBind();
        }
        private void DisplayBooks() 
        {
            ddlBookTitle.DataSource = libService.FindBookTitles();
            ddlBookTitle.DataTextField = "Title";
            ddlBookTitle.DataValueField = "ID";
            ddlBookTitle.DataBind();

            rptBooks.DataSource = libService.FindBooks(); 
            rptBooks.DataBind();
        }
        private void DisplayBookTitles()
        {
            rptBookTitles.DataSource = libService.FindBookTitles(); 
            rptBookTitles.DataBind();
        }

    }
}