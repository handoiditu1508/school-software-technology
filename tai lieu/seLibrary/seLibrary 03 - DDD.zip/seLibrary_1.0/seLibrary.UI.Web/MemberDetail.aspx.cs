﻿using seLibrary.Application;
using seLibrary.Application.Views;
using seLibrary.Model.Members;
using System;
using System.Linq;

namespace seLibrary.UI.Web
{
    public partial class MemberDetail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                string memberId = Request.QueryString["Id"];
                string copyIdToLoan = Request.QueryString["CopyIdToLoan"];
                string copyIdToReturn = Request.QueryString["CopyIdToReturn"];

                if(copyIdToLoan != "")
                {
                    LoanBook(copyIdToLoan, memberId);
                }

                DisplayMember(memberId);
                DisplayBooks();
            }
        }

        private void LoanBook(string copyId, string memberId)
        {
            LibService.LoanBook(copyId, memberId);
        }

        private LibraryService LibService
        {
            get { return ServiceFactory.GetLibraryService("EF"); }
        }
        private void DisplayMember(string memberId)
        {
            MemberView memberFound = LibService.FindMember(memberId);
            if (memberFound != null)
            {
                litName.Text = memberFound.FullName;
                rptLoans.DataSource = memberFound.Loans.OrderBy(l => l.LoanDate);
                rptLoans.DataBind();
            }
        }
        private void DisplayBooks()
        {
            rptBooks.DataSource = LibService.FindBooks();
            rptBooks.DataBind();
        }

        public string DisplayLoanStatus(LoanView loan)
        {
            if (loan.StillOutOnLoan)
            {
                return String.Format(@"due back on {0} <a href=""Memberdetail.aspx?CopyIdToReturn={1}&Id={2}"">return?</a>", loan.DateForReturn, loan.CopyId, loan.MemberId);
            }
            else
            {
                return "returned on " + loan.ReturnDate;
            }
        }
        public string LoanStatus(BookView book)
        {
            if (!string.IsNullOrEmpty(book.OnLoanTo))
            {
                return "On loan to " + book.OnLoanTo;
            }
            return String.Format(@"<a href=""MemberDetail.aspx?Id={0}&CopyIdToLoan={1}"">Loan?</a>", Request.QueryString["Id"], book.BookId); ;
        }


    }
}