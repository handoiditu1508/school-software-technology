﻿using seLibrary.Infrastructure;
using seLibrary.Model.BookTitles;
using System;
using System.Collections.Generic;

namespace seLibrary.Model.Repositories
{
    public interface IBookTitleRepository : IRepository<BookTitle>
    {
    }
}
