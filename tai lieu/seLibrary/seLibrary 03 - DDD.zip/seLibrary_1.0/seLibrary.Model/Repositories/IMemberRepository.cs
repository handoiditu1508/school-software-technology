﻿using seLibrary.Infrastructure;
using seLibrary.Model.Members;

namespace seLibrary.Model.Repositories
{
    public interface IMemberRepository : IRepository<Member>
    {
    }
}
