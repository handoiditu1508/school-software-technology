﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using seLibrary.Model.Books;
using seLibrary.Model.Members;
using seLibrary.Model.Repositories;

namespace seLibrary.Model.Services
{
    public class LoanService
    {
        private IBookRepository bookRepository;
        private IMemberRepository memberRepository;

        public LoanService(IBookRepository bookRepository, IMemberRepository memberRepository)
        {
            this.bookRepository = bookRepository;
            this.memberRepository = memberRepository;
        }

        public Loan Loan(int bookId, int memberId) 
        {
            Loan loan = default(Loan);

            Book book = bookRepository.GetBy(bookId);
            Member member = memberRepository.GetBy(memberId);

            if (member.CanLoan(book))
            {
                loan = member.Loan(book);
                book.OnLoanTo = member;
                memberRepository.Save(member);
                bookRepository.Save(book);
            }

            return loan;
        }
    }
}
