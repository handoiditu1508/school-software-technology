﻿using seLibrary.Infrastructure;
using System;

namespace seLibrary.Model.BookTitles
{
    public class BookTitle : IAggregateRoot
    {
        public int ID { get; set; }
        public string ISBN { get; set; }
        public string Title { get; set; }
        public DateTime? ReleasedDate { get; set; }
    }
}