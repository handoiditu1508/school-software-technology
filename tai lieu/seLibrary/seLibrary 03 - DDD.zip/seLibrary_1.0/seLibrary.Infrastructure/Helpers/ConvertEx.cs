﻿using System;

namespace seLibrary.Infrastructure.Helpers
{
    public static class ConvertEx
    {
        public static int ToInt(this string s)
        {
            return Convert.ToInt32(s);
        }
    }
}
