﻿using System.Collections.Generic;

namespace seLibrary.Infrastructure
{
    public interface IRepository<T> where T : IAggregateRoot
    {
        IList<T> GetAll();
        T GetBy(int id);
        void Save(T entity);
        void Delete(T entity);

    }
}
