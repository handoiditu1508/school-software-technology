﻿using seLibrary.Model.BookTitles;
using seLibrary.Model.Members;
using seLibrary.Model.Repositories;
using System;
using System.Collections.Generic;

namespace seLibrary.Persistence.ADO
{
    public class MemberRepository : IMemberRepository
    {
        public void Delete(Member entity)
        {
            throw new NotImplementedException();
        }

        public IList<Member> GetAll()
        {
            throw new NotImplementedException();
        }

        public Member GetBy(int id)
        {
            throw new NotImplementedException();
        }

        public void Save(Member member)
        {
            throw new NotImplementedException();
        }
    }
}
