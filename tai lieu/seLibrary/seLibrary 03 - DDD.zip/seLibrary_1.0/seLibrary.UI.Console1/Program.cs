﻿using seLibrary.Application;

namespace seLibrary.UI.Console1
{
    class Program
    {
        private static LibraryService libservice;
        static void Main(string[] args)
        {
            //libservice = new LibraryService(new MemberRepository());
            //libservice.AddMember("Duoc", "Huynh");
            //foreach (var item in libservice.FindAllMembers())
            //{
            //    System.Console.WriteLine(item.FirstName + " " + item.LastName);
            //}

            //System.Console.ReadKey();
        }
    }
}
