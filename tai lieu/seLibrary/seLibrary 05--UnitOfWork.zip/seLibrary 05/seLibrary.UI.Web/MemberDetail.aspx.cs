﻿using seLibrary.Application;
using seLibrary.Application.Messages;
using seLibrary.Application.Views;
using System;
using System.Linq;

namespace seLibrary.UI.Web
{
    public partial class MemberDetail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                string memberId = Request.QueryString["Id"];
                string bookIdToLoan = Request.QueryString["CopyIdToLoan"];
                string bookIdToReturn = Request.QueryString["CopyIdToReturn"];

                if(!string.IsNullOrEmpty(bookIdToLoan))
                {
                    LoanBook(bookIdToLoan, memberId);
                }

                if (!string.IsNullOrEmpty(bookIdToReturn))
                {
                    ReturnBook(bookIdToReturn);
                }

                DisplayMember(memberId);
                DisplayBooks();
            }
        }

        private void ReturnBook(string bookId)
        {
            LibService.Return(bookId);
        }

        private void LoanBook(string copyId, string memberId)
        {
            LibService.LoanBook(copyId, memberId);
        }

        private LibraryService LibService
        {
            get { return ServiceFactory.GetLibraryService("EF"); }
        }

        private void DisplayMember(string memberId)
        {
            FindMemberRequest request = new FindMemberRequest() { MemberId = memberId };
            FindMemberResponse response = LibService.FindMembers(request);

            if (response.Success)
            {
                MemberView memberFound = response.MembersFound.FirstOrDefault();
                litName.Text = memberFound.FullName;
                rptLoans.DataSource = memberFound.Loans.OrderBy(l => l.LoanDate);
                rptLoans.DataBind();
            }
        }

        private void DisplayBooks()
        {
            FindBookResponse response = LibService.FindBooks();
            rptBooks.DataSource = response.Books;
            rptBooks.DataBind();
        }

        public string DisplayLoanStatus(LoanView loan)
        {
            if (loan.StillOutOnLoan)
            {
                return String.Format(@"due back on {0} <a href=""Memberdetail.aspx?CopyIdToReturn={1}&Id={2}"">return?</a>", loan.DateForReturn, loan.BookId, loan.MemberId);
            }
            else
            {
                return "returned on " + loan.ReturnDate;
            }
        }

        public string LoanStatus(BookView book)
        {
            if (!string.IsNullOrEmpty(book.OnLoanTo))
            {
                return "On loan to " + book.OnLoanTo;
            }
            return String.Format(@"<a href=""MemberDetail.aspx?Id={0}&CopyIdToLoan={1}"">Loan?</a>", Request.QueryString["Id"], book.BookId); ;
        }
    }
}