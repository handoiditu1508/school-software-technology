﻿using seLibrary.Application;

namespace seLibrary.UI.Web
{
    public class ServiceFactory
    {
        public static LibraryService GetLibraryService(string persistenceStrategy)
        {
            if (persistenceStrategy == "EF")
            {
                return new LibraryService(new Persistence.EF.Repositories.MemberRepository(),
                                          new Persistence.EF.Repositories.BookRepository(),
                                          new Persistence.EF.Repositories.BookTitleRepository(),
                                          new Persistence.EF.UnitOfWork());
            }
            if (persistenceStrategy == "ADO")
            {
                return new LibraryService(null, null, null, null);
            }
            return null;
        }
    }
}
