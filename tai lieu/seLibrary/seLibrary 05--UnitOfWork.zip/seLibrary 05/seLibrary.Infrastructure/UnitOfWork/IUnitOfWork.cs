﻿namespace seLibrary.Infrastructure.UnitOfWork
{
    public interface IUnitOfWork
    {
        void RegisterNew(IAggregateRoot entity, IUnitOfWorkRepository repository);
        void RegisterAmended(IAggregateRoot entity, IUnitOfWorkRepository repository);
        void RegisterRemoved(IAggregateRoot entity, IUnitOfWorkRepository repository);
        void Commit();
    }
}
