﻿namespace seLibrary.Infrastructure
{
    public interface IAggregateRoot
    {
    }
}
