﻿using System.Collections.Generic;

namespace seLibrary.Infrastructure
{
    public interface IRepository<T> where T : IAggregateRoot
    {
        IEnumerable<T> FindAll();
        T FindBy(int id);
    }
}
