﻿using seLibrary.Infrastructure;
using seLibrary.Infrastructure.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Transactions;

namespace seLibrary.Persistence.ADO
{
    public class UnitOfWork : IUnitOfWork
    {
        private Dictionary<IAggregateRoot, IUnitOfWorkRepository> addedEntities;
        private Dictionary<IAggregateRoot, IUnitOfWorkRepository> changedEntities;
        private Dictionary<IAggregateRoot, IUnitOfWorkRepository> deletedEntities; 

        public void Commit()
        {
            using (TransactionScope scope = new TransactionScope())
            {
                foreach (IAggregateRoot entity in addedEntities.Keys)
                {
                    addedEntities[entity].PersistCreationOf(entity);
                }
                foreach (IAggregateRoot entity in changedEntities.Keys)
                {
                    addedEntities[entity].PersistUpdateOf(entity);
                }
                foreach (IAggregateRoot entity in deletedEntities.Keys)
                {
                    addedEntities[entity].PersistDeletionOf(entity);
                }
            }
        }

        public void RegisterNew(IAggregateRoot entity, IUnitOfWorkRepository repository)
        {
            if (!addedEntities.ContainsKey(entity))
            {
                addedEntities.Add(entity, repository);
            }
        }
        public void RegisterAmended(IAggregateRoot entity, IUnitOfWorkRepository repository)
        {
            if (!changedEntities.ContainsKey(entity))
            {
                changedEntities.Add(entity, repository);
            }
        }

        public void RegisterRemoved(IAggregateRoot entity, IUnitOfWorkRepository repository)
        {
            if (!deletedEntities.ContainsKey(entity))
            {
                deletedEntities.Add(entity, repository);
            }
        }
    }
}
