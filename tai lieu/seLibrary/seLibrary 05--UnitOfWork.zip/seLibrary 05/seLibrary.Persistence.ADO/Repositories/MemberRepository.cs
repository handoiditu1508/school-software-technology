﻿using System.Collections.Generic;
using seLibrary.Model.Members;
using seLibrary.Model.Repositories;

namespace seLibrary.Persistence.ADO.Repositories
{
    public class MemberRepository : Repository<Member>, IMemberRepository
    {

        public IEnumerable<Member> FindAll()
        {
            throw new System.NotImplementedException();
        }

        public Member FindBy(int Id)
        {
            throw new System.NotImplementedException();
        }
    }
}
