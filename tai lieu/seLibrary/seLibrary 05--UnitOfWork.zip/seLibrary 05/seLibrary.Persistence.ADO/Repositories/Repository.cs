﻿using seLibrary.Infrastructure;

namespace seLibrary.Persistence.ADO.Repositories
{
    public abstract class Repository<T> where T : IAggregateRoot
    {
    }
}
