﻿using System.Collections.Generic;

namespace seLibrary.Application.Views
{
    public class MemberView
    {
        public int MemberId { get; set; }
        public string FullName { get; set; }
        public IEnumerable<LoanView> Loans { get; set; }
    }
}
