﻿namespace seLibrary.Application.Views
{
    public class BookTitleView
    {
        public string ID { get; set; }
        public  string ISBN { get; set; }
        public string Title { get; set; }
    }
}
