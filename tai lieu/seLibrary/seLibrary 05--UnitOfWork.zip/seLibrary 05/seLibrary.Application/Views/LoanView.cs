﻿using System;

namespace seLibrary.Application.Views
{
    public class LoanView
    {
        public string LoanId { get; set; }
        public string BookTitle { get; set; }
        public string BookId { get; set; }
        public string LoanDate { get; set; }
        public string ReturnDate { get; set; }
        public string DateForReturn { get; set; }
        public string MemberId { get; set; }
        public string MemberName { get; set; }
        public bool StillOutOnLoan { get; set; }
    }
}
