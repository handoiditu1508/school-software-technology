﻿namespace seLibrary.Application.Views
{
    public class BookView
    {
        public int BookId { get; set; }
        public string ISBN { get; set; }
        public string Title { get; set; }
        public string OnLoanTo { get; set; }
    }
}
