﻿namespace seLibrary.Application.Messages
{
    public abstract class ResponseBase
    {
        public bool Success { get; set; }
    }
}