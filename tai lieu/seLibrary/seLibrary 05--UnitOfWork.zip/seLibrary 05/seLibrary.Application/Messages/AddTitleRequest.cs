﻿namespace seLibrary.Application.Messages
{
    public class AddTitleRequest 
    {
        public string ISBN { get; set; }
        public string Title { get; set; }
    }
}
