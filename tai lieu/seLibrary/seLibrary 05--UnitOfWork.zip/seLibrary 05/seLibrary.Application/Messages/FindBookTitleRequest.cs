﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seLibrary.Application.Messages
{
    public class FindBookTitleRequest
    {
        public string ISBN { get; set; }
        public bool All { get; set; }
    }
}
