﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seLibrary.Application.Messages
{
    public class AddMemberRequest
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
