﻿using seLibrary.Application.Views;
using System.Collections.Generic;

namespace seLibrary.Application.Messages
{
    public class FindMemberResponse : ResponseBase
    {
        public IEnumerable<MemberView> MembersFound { get; set; }
    }
}
