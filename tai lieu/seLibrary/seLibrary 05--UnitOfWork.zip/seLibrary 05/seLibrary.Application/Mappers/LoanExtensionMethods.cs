﻿using seLibrary.Application.Views;
using seLibrary.Model.Members;
using System.Collections.Generic;

namespace seLibrary.Application.Mappers
{
    public static class LoanExtensionMethods
    {
        public static LoanView ConvertToLoanView(this Loan loan)
        {
            return new LoanView()
            {
                BookTitle = loan.Book.BookTitle.Title,
                BookId = loan.Book.ID.ToString(),
                LoanId = loan.ID.ToString(),
                DateForReturn = loan.DateForReturn != null ? loan.DateForReturn.ToString() : string.Empty,
                LoanDate = loan.LoanDate.ToString(),
                MemberId = loan.Member.ID.ToString(),
                MemberName = loan.Member.FirstName + " " + loan.Member.LastName,
                ReturnDate = loan.ReturnDate != null ? loan.ReturnDate.ToString() : string.Empty,
                StillOutOnLoan = loan.HasNotBeenReturned()
            };
        }
        public static IEnumerable<LoanView> ConvertToLoanViews(this IEnumerable<Loan> loans)
        {
            foreach (Loan loan in loans)
            {
                yield return loan.ConvertToLoanView();
            }
        }
    }
}
