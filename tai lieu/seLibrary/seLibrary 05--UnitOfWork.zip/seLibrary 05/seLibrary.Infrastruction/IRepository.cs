﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seLibrary.Infrastruction
{
    public interface IRepository<T> where T : AggregateRoot
    {
        IList<T> GetAll();
        T GetBy(int id);
        void Save(T entity);
        void Delete(int id);
    }
}
