﻿namespace seLibrary.Domain.Members
{
    public class Address
    {
        public Address(string number,string street,string ward,string district)
        {
            Number = number;
            Street = street;
            Ward = ward;
            District = district;
        }
        public string Number { get; private set; }
        public string Street { get; private set; }
        public string Ward { get; private set; }
        public string District { get; private set; }
    }
}