﻿namespace seLibrary.Model.BookTitles
{
    public class Author
    {
        public int ID { get; set; }
        public string FullName { get; set; }
    }
}