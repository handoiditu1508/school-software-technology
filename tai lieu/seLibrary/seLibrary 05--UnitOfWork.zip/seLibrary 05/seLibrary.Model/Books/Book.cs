﻿using seLibrary.Model.Books;
using seLibrary.Infrastructure;
using System;
using seLibrary.Model.BookTitles;
using seLibrary.Model.Members;

namespace seLibrary.Model.Books
{
    public class Book : IAggregateRoot
    {
        public int ID { get; set; }
        public virtual BookTitle BookTitle { get; set; }
        public virtual Author Author { get; set; }
        public virtual Publisher Publisher { get; set; }
        public virtual Member OnLoanTo { get; set; }
    }
}
