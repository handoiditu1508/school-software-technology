﻿using seLibrary.Model.BookTitles;
using System.Collections.Generic;

namespace seLibrary.Model.Repositories
{
    public interface IBookTitleRepository //: IRepository<BookTitle>
    {
        BookTitle FindBy(int Id);
        IEnumerable<BookTitle> FindAll();
    }
}
