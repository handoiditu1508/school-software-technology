﻿using System;
using System.Collections.Generic;
using seLibrary.Infrastructure;
using seLibrary.Model.Books;

namespace seLibrary.Model.Repositories
{
    public interface IBookRepository : IRepository<Book>
    {
    }
}
