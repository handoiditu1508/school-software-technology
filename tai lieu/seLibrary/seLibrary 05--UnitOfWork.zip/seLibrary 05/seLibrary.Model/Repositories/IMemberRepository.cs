﻿using seLibrary.Model.Members;
using System.Collections.Generic;

namespace seLibrary.Model.Repositories
{
    public interface IMemberRepository 
    {
        Member FindBy(int Id);
        IEnumerable<Member> FindAll();
    }
}
