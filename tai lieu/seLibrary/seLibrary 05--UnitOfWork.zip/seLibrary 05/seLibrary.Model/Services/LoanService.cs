﻿using seLibrary.Infrastructure.UnitOfWork;
using seLibrary.Model.Books;
using seLibrary.Model.Members;
using seLibrary.Model.Repositories;

namespace seLibrary.Model.Services
{
    public class LoanService
    {
        private IBookRepository bookRepository;
        private IMemberRepository memberRepository;
        private IUnitOfWork unitOfWork;

        public LoanService( IBookRepository bookRepository, IMemberRepository memberRepository, IUnitOfWork unitOfWork)
        {
            this.bookRepository = bookRepository;
            this.memberRepository = memberRepository;
            this.unitOfWork = unitOfWork;
        }

        public Loan Loan(int bookId, int memberId) 
        {
            Loan loan = default(Loan);

            Book book = bookRepository.FindBy(bookId);
            Member member = memberRepository.FindBy(memberId);

            if (member.CanLoan(book))
            {
                loan = member.Loan(book);
                //memberRepository.Save(member);
                //bookRepository.Save(book);
                unitOfWork.Commit();
                
            }

            return loan;
        }

        public void Return(Book book)
        {
            Member member = book.OnLoanTo;
            member.Return(book);
            //memberRepository.Save(member);
            //bookRepository.Save(book);
            unitOfWork.Commit();
        }
    }
}
