﻿using seLibrary.Infrastructure;
using seLibrary.Model.Books;
using System;
using System.Collections.Generic;
using System.Linq;

namespace seLibrary.Model.Members
{
    public class Member : IAggregateRoot
    {
        public int ID { get; set; }
        public string FirstName { get; set; } 
        public string LastName { get; set; }
        public DateTime? Birthday { get; set; }
        //public Address Address { get; set; }
        public virtual ICollection<Loan> Loans { get; private set; }

        internal Loan Loan(Book book)
        {
            Loan loan = new Loan() { Book = book, Member = this, LoanDate = DateTime.Now };
            Loans.Add(loan);
            book.OnLoanTo = this;
            return loan;
        }
        internal bool CanLoan(Book book)
        {
            return (book != null && book.OnLoanTo == null);
        }

        internal void Return(Book book)
        {
            Loan loan = CurrentOutstandingLoanFor(book);
            if (loan != null)
            {
                loan.ReturnDate = DateTime.Now;
                book.OnLoanTo = null;
            }

        }

        private Loan CurrentOutstandingLoanFor(Book book)
        {
            return Loans.FirstOrDefault(l => l.Book.ID == book.ID && l.ReturnDate == null);
        }
    }
}
