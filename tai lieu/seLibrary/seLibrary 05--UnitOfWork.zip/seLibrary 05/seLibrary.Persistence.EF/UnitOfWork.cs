﻿using seLibrary.Infrastructure;
using seLibrary.Infrastructure.UnitOfWork;

namespace seLibrary.Persistence.EF
{
    public class UnitOfWork : IUnitOfWork
    {
        public void Commit()
        {
            LibraryContext.Instance.SaveChanges();
        }

        public void RegisterNew(IAggregateRoot entity, IUnitOfWorkRepository repository)
        {
            repository.PersistCreationOf(entity);
        }

        public void RegisterAmended(IAggregateRoot entity, IUnitOfWorkRepository repository)
        {
            repository.PersistUpdateOf(entity);
        }

        public void RegisterRemoved(IAggregateRoot entity, IUnitOfWorkRepository repository)
        {
            repository.PersistDeletionOf(entity);
        }
    }
}
