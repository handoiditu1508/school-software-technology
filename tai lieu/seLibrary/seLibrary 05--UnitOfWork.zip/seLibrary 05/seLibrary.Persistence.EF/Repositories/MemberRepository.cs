﻿using seLibrary.Model.Members;
using seLibrary.Model.Repositories;
using System.Collections.Generic;
using System.Linq;

namespace seLibrary.Persistence.EF.Repositories
{
    public class MemberRepository : Repository<Member>, IMemberRepository
    {

        public override Member FindBy(int id)
        {
            return LibraryDB.Members.FirstOrDefault(m => m.ID == id);
        }

        public override IQueryable<Member> GetEntitySet()
        {
            return LibraryDB.Members;
        }
    }
}
