﻿using seLibrary.Model.BookTitles;
using seLibrary.Model.Repositories;
using System.Linq;

namespace seLibrary.Persistence.EF.Repositories
{
    public class BookTitleRepository : Repository<BookTitle>, IBookTitleRepository
    {

        public override BookTitle FindBy(int id)
        {
            return LibraryDB.BookTitles.FirstOrDefault(m => m.ID == id);
        }

        public override IQueryable<BookTitle> GetEntitySet()
        {
            return LibraryDB.BookTitles;
        }
    }
}
