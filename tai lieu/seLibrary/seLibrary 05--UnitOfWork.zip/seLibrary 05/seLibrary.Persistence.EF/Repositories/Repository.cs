﻿using seLibrary.Infrastructure;
using seLibrary.Infrastructure.UnitOfWork;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace seLibrary.Persistence.EF.Repositories
{
    public abstract class Repository<T> :  IUnitOfWorkRepository where T : IAggregateRoot
    {
        protected LibraryContext LibraryDB
        {
            get { return LibraryContext.Instance; }
        }

        #region Abstract methods
        public abstract IQueryable<T> GetEntitySet();
        public abstract T FindBy(int id);
        #endregion

        #region Query entities
        public IEnumerable<T> FindAll()
        {
            return GetEntitySet().ToList<T>();
        }
        #endregion

        #region UnitOfWork
        public void PersistCreationOf(IAggregateRoot entity)
        {
            //LibraryDB.Members.Add((entity as Member));
            LibraryDB.Entry(entity).State = EntityState.Added;
        }
        public void PersistDeletionOf(IAggregateRoot entity)
        {
            //throw new NotImplementedException();
            LibraryDB.Entry(entity).State = EntityState.Deleted;
        }
        public void PersistUpdateOf(IAggregateRoot entity)
        {
            LibraryDB.Entry(entity).State = EntityState.Modified;
        }
        #endregion
    }
}
