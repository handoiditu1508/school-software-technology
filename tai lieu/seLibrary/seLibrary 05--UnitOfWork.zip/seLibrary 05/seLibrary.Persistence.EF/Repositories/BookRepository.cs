﻿using seLibrary.Infrastructure;
using seLibrary.Model.Books;
using seLibrary.Model.Repositories;
using System.Collections.Generic;
using System.Linq;

namespace seLibrary.Persistence.EF.Repositories
{
    public class BookRepository : Repository<Book>, IBookRepository
    {
        public override Book FindBy(int id)
        {
            return LibraryDB.Books.FirstOrDefault(m => m.ID == id);
        }
        public override IQueryable<Book> GetEntitySet()
        {
            return LibraryDB.Books;
        }
    }
}
