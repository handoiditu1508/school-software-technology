﻿using seLibrary.Model.Books;
using seLibrary.Model.BookTitles;
using seLibrary.Model.Members;
using System;
using System.Collections.Generic;
using System.Data.Entity;

namespace seLibrary.Persistence.EF
{
    public class LibraryInitializer : DropCreateDatabaseIfModelChanges<LibraryContext>
    {
        protected override void Seed(LibraryContext context)
        {
            var bookTitles = new List<BookTitle>() {
                new BookTitle { ISBN = "133334343", Title = "Dat rung phuong nam" },
                new BookTitle { ISBN = "348204848", Title = "Mot ngay dai hon the ky" }
            };

            var books = new List<Book> {
                new Book() { BookTitle = bookTitles[0] },
                new Book() { BookTitle = bookTitles[1] }
            };

            var members = new List<Member>
            {
                new Member{ FirstName="Duoc", LastName="Huynh", Birthday=new DateTime(1978,2,20) },
                new Member{ FirstName="Linh", LastName="Trinh", Birthday=new DateTime(1978,5,9) }
            };

            bookTitles.ForEach(t => context.BookTitles.Add(t));
            books.ForEach(b => context.Books.Add(b));
            members.ForEach(m => context.Members.Add(m));

            context.SaveChanges();
        }
    }
}
